import React from 'react';

class Root extends React.Component {
  render() {
    return (
      <h1>Blog App</h1>
    )
  }
}

export default Root;
