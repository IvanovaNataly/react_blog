# Blog App

## Init

Run `npm install` and then `npm start`

## Instructions

Open README.html in the browser
